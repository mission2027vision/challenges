# ShellBank Ocean Rangers

ShellBank `Progress and Impact Report 2023/24`의 공개 수치와 사례를 바탕으로 만든 한국어 지도형 학습 미션입니다.

## 주요 기능

- 세계 지도 기반 8개 현장 미션
- 실제 리포트 수치가 포함된 브리핑·퀴즈·근거 해설
- 대모거북/푸른바다거북 데이터 비교 도감
- XP, 등급, 첫 도전 보너스, 진행 상황 자동 저장
- 전체 미션 완료 후 인쇄 가능한 Ocean Ranger 인증서
- 모바일 반응형 및 키보드 접근성 지원

## 실행

정적 웹 앱이므로 `index.html`을 브라우저에서 열면 됩니다. 로컬 서버를 쓰려면:

```bash
python3 -m http.server 8000
```

그다음 `http://localhost:8000`으로 접속합니다.

지도, 웹폰트, Leaflet 라이브러리는 CDN을 사용하므로 인터넷 연결이 필요합니다. GitHub Pages에서는 별도의 빌드 과정 없이 루트 디렉터리를 배포하면 됩니다.

## 데이터 출처

*ShellBank: Marine Turtle Traceability Tool, Progress and Impact Report 2023/24* (ShellBank, 2024; published February 2025). 각 미션 안에 관련 페이지를 표시했습니다.

본 콘텐츠는 교육용 인터랙티브 시안이며, 공개 전 WWF/ShellBank의 브랜드·번역·데이터 최신성 검수를 권장합니다.
